<template>
    <h1>Menu</h1>
</template>

<script>
    export default {
        name: 'Menu',
    }
</script>

<style scoped>

</style>