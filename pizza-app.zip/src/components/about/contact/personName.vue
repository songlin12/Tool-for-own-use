<template>
  <div>
    <h4>jo太郎</h4>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>